package com.assignment.service;
/**
 * @author User
 * This interface is used to log
 */
public interface ILoggerService {
	public void log(String content);
	public void closeResource();
}
