package com.assignment.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Map;

import com.assignment.service.DrawingFactory;
import com.assignment.service.DrawingService;
import com.assignment.service.ILoggerService;
import com.assignment.service.LoggerFactory;
/**
 * @author User
 * This class is used to run assignment
 * Input is given through console
 */
public class DrawingController {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		BufferedReader br = null;
        
        try
        {
        	br = new BufferedReader(new InputStreamReader(System.in));
        	Map<Integer, String[]> previousPattern = null;
        	ILoggerService loggerService = LoggerFactory.getLogger("File");
			while(true)
			{
				 System.out.print("enter command: ");
	             String[] input = br.readLine().split(" ");
	             
	             if ("q".equalsIgnoreCase(input[0])) {
	                 System.out.println("Exit!");
	                 loggerService.closeResource();
	                 System.exit(0);
	             }
	            
				DrawingService drawingService = DrawingFactory.getDrawingService(input[0]);
				drawingService.setLoggerService(null);
				String[] attributes = Arrays.copyOfRange(input, 1, input.length);
				drawingService.setPreviousPattern(previousPattern);
				drawingService.validateAndPopulateAttributes(attributes);
				drawingService.draw();
				drawingService.setLoggerService(loggerService);
				drawingService.draw();
				previousPattern = drawingService.getPreviousPattern();
			}
        }
        catch(Exception e)
        {
        	System.out.println(e.getMessage());
        }
        finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

	}

}
