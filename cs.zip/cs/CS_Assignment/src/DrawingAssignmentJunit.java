import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.assignment.service.DrawingFactory;
import com.assignment.service.DrawingService;
import com.assignment.service.ILoggerService;
import com.assignment.service.LoggerFactory;

/**
 * @author User
 * This class is used to test assignmnet
 */
public class DrawingAssignmentJunit {

	@Test
	public void test() {
		String[] junitInput = new String[4];
		junitInput[0] = "C 20 4";
		junitInput[1] = "L 1 2 6 2";
		junitInput[2] = "L 6 3 6 4";
		junitInput[3] = "R 14 1 18 3";
		Map<Integer, String[]> previousPattern = null;
    	ILoggerService loggerService = LoggerFactory.getLogger("File");
		for(String s : junitInput)
		{
			 String[] input = s.split(" ");
			DrawingService drawingService = DrawingFactory.getDrawingService(input[0]);
			drawingService.setLoggerService(loggerService);
			String[] attributes = Arrays.copyOfRange(input, 1, input.length);
			drawingService.setPreviousPattern(previousPattern);
			drawingService.validateAndPopulateAttributes(attributes);
			drawingService.draw();
			previousPattern = drawingService.getPreviousPattern();
		}
		loggerService.closeResource();
		BufferedReader brOutput = null;
		FileReader froutput= null;
		BufferedReader brinput = null;
		FileReader frinput= null;

		try {

			froutput = new FileReader("output.txt");
			brOutput = new BufferedReader(froutput);
			frinput = new FileReader("input.txt");
			brinput = new BufferedReader(froutput);

			String outputcurrentline;
			String inputcurrentline;

			brOutput = new BufferedReader(froutput);
			brinput = new BufferedReader(frinput);

			while ((outputcurrentline = brOutput.readLine()) != null && (inputcurrentline = brinput.readLine()) != null) {
				Assert.assertTrue(outputcurrentline.equals(inputcurrentline));
			}

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (brOutput != null)
				{
					brOutput.close();
					brinput.close();
				}
				if (froutput != null)
				{
					froutput.close();
					frinput.close();
				}
			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}

	}

}
